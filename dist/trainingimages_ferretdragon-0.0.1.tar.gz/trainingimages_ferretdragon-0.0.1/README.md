<div class="green">

# TRAININGIMAGES  

### Purpose:  
Open images from a directory and determine whether they contain a specific feature that the user is looking for 



</div>

<style>
.green{
    color:green;
    sont-size:30px;
}
</style>